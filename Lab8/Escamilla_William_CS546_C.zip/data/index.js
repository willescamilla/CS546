const peopleApi = require("./people");

module.exports = { searchPeople: peopleApi };
