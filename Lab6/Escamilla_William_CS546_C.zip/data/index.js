const moviesData = require("./movies");
const reviewsData = require("./reviews");

module.exports = {
  moviesApi: moviesData,
  reviewsApi: reviewsData,
};
